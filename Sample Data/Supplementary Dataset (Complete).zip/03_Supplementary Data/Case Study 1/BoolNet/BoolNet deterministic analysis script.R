library("BoolNet", lib.loc="~/R/win-library/3.4")

cell <- loadNetwork("Cell cyle network boolNet.txt")
plotNetworkWiring(cell)
attr <- getAttractors(cell,canonical = FALSE)
attr
