Description of acronymes used in the mutation file name:
0_Nutlin = "0"-> No DNA damage, "Nutlin"-> Treatment with Nutlin (MDM2 > P53 interaction inhibitor).
Wip1 KD = "Wip1"-> PPM1D, "KD"-> Knock down.