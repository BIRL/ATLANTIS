library("BoolNet", lib.loc="~/R/win-library/3.2")


# Control-> DNA Damage off
cell <- loadNetwork("Control (0).txt")
attr <- getAttractors(cell, canonical = FALSE)
attr

# DNA Damage off + Wip1 inhibition
cell <- loadNetwork("Control (0).txt")
attr <- getAttractors(cell, genesOFF = c("wip1"), canonical = FALSE)
attr

# DNA Damage off + Nutlin (MDM2-P53 interaction inhibition)
cell <- loadNetwork("0_Nutlin.txt")
attr <- getAttractors(cell, canonical = FALSE)
attr

# DNA Damage off + Nutlin (MDM2-P53 interaction inhibition) + Wip1 inhibition
cell <- loadNetwork("0_Nutlin.txt")
attr <- getAttractors(cell, genesOFF = c("wip1"), canonical = FALSE)
attr

# Etoposide (DNA Damage on)
cell <- loadNetwork("Etoposide.txt")
attr <- getAttractors(cell, canonical = FALSE)
attr

# Etoposide (DNA Damage on) + Wip1 inhibition
cell <- loadNetwork("Etoposide.txt")
attr <- getAttractors(cell, genesOFF = c("wip1"), canonical = FALSE)
attr

# Etoposide (DNA Damage on) + Nutlin (MDM2-P53 interaction inhibition)
cell <- loadNetwork("Etoposide_Nutlin3.txt")
attr <- getAttractors(cell, canonical = FALSE)
attr

# Etoposide (DNA Damage on) + Nutlin (MDM2-P53 interaction inhibition) + Wip1 inhibition
cell <- loadNetwork("Etoposide_Nutlin3.txt")
attr <- getAttractors(cell, genesOFF = c("wip1"), canonical = FALSE)
attr


