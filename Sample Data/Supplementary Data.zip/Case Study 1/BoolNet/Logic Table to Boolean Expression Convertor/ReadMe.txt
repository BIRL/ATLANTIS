Names of the logic files should be the name of the target/child node.

Note: Names of the nodes inside the logic files should not contain ',' or '-'. For example, Cln1,3 is not supported by boolNet and is an invalid name.