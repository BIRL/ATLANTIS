This input data has been inferred from the work of Han et al.

The interaction weights are in 'From - To' format. The nodes in the first column are the parent nodes. The nodes in the first row are the child nodes. The interaction is 'From' parent node 'To' child node.

We used '-1' as the interaction weight for self-inhibition loops.